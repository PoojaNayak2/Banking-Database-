package com.user;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		String username=request.getParameter("username");
		String password=request.getParameter("password");
		String confirm=request.getParameter("confirm");
		
		String driver="oracle.jdbc.driver.OracleDriver";
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		
		if(password.equals(confirm)) 
		{
			try
			{
				Class.forName(driver);
				Connection con=DriverManager.getConnection(url,"pooja","200212");
				
				String query="insert into register values(?,?)";
				PreparedStatement ps=con.prepareStatement(query);
				
				ps.setString(1, username);
				ps.setString(2, password);
				
				ResultSet rs=ps.executeQuery();
				
				if (rs.next())
				{
					out.println("Succesfully Registered");
				}
				
				else
				{
					out.println("Not Registered");
				}
				
			}
			catch(Exception e)
			{
				out.println("<h4>Exception :" + e.getMessage()+"</h4>");
			}
			
		}
		
		}
		
	}
	

